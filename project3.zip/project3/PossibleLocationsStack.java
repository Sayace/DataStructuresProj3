package project3;
/**
 * This is an implementation of the PossibleLocations interface used to make a stack
 * The goal is to store location spaces and search for a way out of a maze algorithm
 * This is a stack so it follows the Last In First Out Rule
 * 
 * @author Alice Han
 *
 */
public class PossibleLocationsStack implements PossibleLocations{
	//Node class copied from 3.2.1 in lecture notes and textbook page 126
		private class Node<T>{
			private Location data;
			
			private Node<Location> next;
			
			public Node(Location initial, Node<Location>n) {
				data=initial;
				next=n;
			}

			public Location getData() {
				return data;
			}
			
			public Node<Location> getNext(){
				return next;
			}
			
			public void setData (Location data) {
				this.data = data;
			}
			public void setNext (Node<Location> next) {
				this.next = next;
			}
		}
		//Create the variables for head
		private Node<Location> head;
	
	/**
	 * Add a SquarePosition object to the set.
	 * @param s
	 *    object to be added
	*/
	@Override
	public void add(Location s) {
		//check if s is valid, if it is null throw exception
		if (s==null) {
			throw new NullPointerException();
		}
		//add to head if stack is empty
		else if(head==null) {
			head=new Node<Location>(s,null);
		}
		//add to stack so that head is pointing to the recent addition
		else {
			Node<Location> sAsNode=new Node<Location>(s,head);
			head=sAsNode;
		}
	}

	/**
	 * Remove the next object from the set. The specific
	 * item returned is determined by the underlying structure
	 * of set representation.
	 * @return
	 *    the next object, or null if set is empty
	 */
	@Override
	public Location remove() {
		//if stack is empty then return null
		if(head==null) {
			return null;
		}
		//if there is only one element in the stack we return the head
		else if(head.getNext()==null) {
			Location toReturn=head.getData();
			head=null;
			return toReturn;
		}
		//we return the head because we return the last element to be added and assign head to next to last added element
		else {
			Location toReturn=head.getData();
			head=head.getNext();
			return toReturn;
		}
	}

	/**
	 * Determines if set is empty or not.
	 * @return
	 *    true, if set is empty,
	 *    false, otherwise.
	 */
	@Override
	public boolean isEmpty() {
		//if head is null then there are no elements in the satck
		if(head==null) {
			return true;
		}
		return false;
	}

}
