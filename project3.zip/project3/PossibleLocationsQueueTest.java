package project3;

import static org.junit.Assert.*;


import org.junit.Test;
/**
 * Tests for queue implementation of PossibleLocations
 * @author Alice Han
 *
 */
public class PossibleLocationsQueueTest {
	//test making no parameter constructor
	@Test
	public void testNoParameterConstructor() {
		//create empty queue
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
	}
	//test making constructor when given valid capacity
	@Test
	public void testConstructorValidParameter() {
		try {
			//create queue of capacity 10
			PossibleLocationsQueue testQueue=new PossibleLocationsQueue(10);
		}
		//if exception is thrown when the parameter is right we use fail
		catch (IllegalArgumentException e ) {
			fail("Exception thrown incorrectly (for valid arguments).");
		}		
	}
	//test making constructor when given invalid capacity
	@Test
	public void testConstructorInValidParameter() {
		try {
			//if exception is not thrown when paramater is invalid then we use fail
			PossibleLocationsQueue testQueue=new PossibleLocationsQueue(-10);
			fail("IllegalArgumentException not thrown with invalid constructor parameters.");
		}
		catch (IllegalArgumentException e ) {
			//do nothing as it is doing its job
		}		
	}
	//test isEmpty when you make empty queue
	@Test
	public void testIsEmptyWhenEmpty() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
		//assertTrue to confirm queue is empty when it should be
		assertTrue("Queue should be empty", testQueue.isEmpty());
	}
	//test isEmpty when you make empty queue
	@Test
	public void testIsEmptyWhenNotEmpty() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
		Location testLocation1=new Location(1,2);
		//add to queue
		testQueue.add(testLocation1);
		//assertFalse to confirm queue is not empty when it should be
		assertFalse("Queue should not be empty", testQueue.isEmpty());
	}
	//test add method when adding to empty queue
	@Test
	public void testAddRemove() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
		Location testLocation1=new Location(1,2);
		//add to queue
		testQueue.add(testLocation1);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		//remove first element from queue
		Location removed=testQueue.remove();
		//check if the add and remove methods correctly dealt with the right element
		assertEquals("Returned element should be testLocation1.", removed,testLocation1);
		//assertTrue to confirm queue is empty when it should be
		assertTrue("Queue should be empty", testQueue.isEmpty());
	}
	//test remove method when removing from empty queue
	@Test
	public void testRemove() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
		assertTrue("Queue should be empty", testQueue.isEmpty());
		//if remove method used on empty list it should return null
		Location removed=testQueue.remove();
		assertEquals("Removed result should be null.", removed,null);
		assertTrue("Queue should be empty", testQueue.isEmpty());
	}
	//test adding multiple elements, removing all of them, and if isEmpty works after each method call
	@Test
	public void testAddRemoveMultiple() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
		Location testLocation1=new Location(1,2);
		Location testLocation2=new Location(3,4);	
		Location testLocation3=new Location(5,6);
		Location testLocation4=new Location(7,8);	
		//add multiple elements
		testQueue.add(testLocation1);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		testQueue.add(testLocation2);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		testQueue.add(testLocation3);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		testQueue.add(testLocation4);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		//check if remove removes and returns elements in correct queue order (removed oldest element in queue)
		Location removed1=testQueue.remove();
		assertEquals("Returned element should be testLocation1.", removed1,testLocation1);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed2=testQueue.remove();
		assertEquals("Returned element should be testLocation2.", removed2,testLocation2);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed3=testQueue.remove();
		assertEquals("Returned element should be testLocation3.", removed3,testLocation3);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed4=testQueue.remove();
		assertEquals("Returned element should be testLocation4.", removed4,testLocation4);
		assertTrue("Queue should be empty", testQueue.isEmpty());
		//if remove method used on empty list it should return null
		Location removed5=testQueue.remove();
		assertEquals("Returned element should be testLocation4.", removed5,null);
		assertTrue("Queue should be empty", testQueue.isEmpty());
	}
	//test add method when adding null to queue
	@Test
	public void testAddNull() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue();
		try {
			testQueue.add(null);
		}
		//if NullPointerException is thrown then it was successful
		catch (NullPointerException success) {
			return;
		}
		//if it reaches this line then exception handling failed
		fail("Didn't throw Null Pointer exception");
	}
	//test for add method making larger queue when capacity is full
	@Test
	public void testlargerQueue() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue(2);
		Location testLocation1=new Location(1,2);
		Location testLocation2=new Location(3,4);	
		Location testLocation3=new Location(5,6);
		Location testLocation4=new Location(7,8);
		//add multiple locations
		testQueue.add(testLocation1);
		testQueue.add(testLocation2);			
		testQueue.add(testLocation3);
		testQueue.add(testLocation4);
		//remove all elements and see if they are in order
		Location removed1=testQueue.remove();
		assertEquals("Returned element should be testLocation1.", removed1,testLocation1);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed2=testQueue.remove();
		assertEquals("Returned element should be testLocation2.", removed2,testLocation2);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed3=testQueue.remove();
		assertEquals("Returned element should be testLocation3.", removed3,testLocation3);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed4=testQueue.remove();
		assertEquals("Returned element should be testLocation4.", removed4,testLocation4);
		assertTrue("Queue should be empty", testQueue.isEmpty());
	}
	//test for add method making larger queue when capacity is full and to see if order of queue is maintained
	//after removing and adding
	@Test
	public void testlargerQueueOrder() {
		PossibleLocationsQueue testQueue=new PossibleLocationsQueue(2);
		Location testLocation1=new Location(1,2);
		Location testLocation2=new Location(3,4);	
		Location testLocation3=new Location(5,6);
		Location testLocation4=new Location(7,8);
		
		testQueue.add(testLocation1);
		testQueue.add(testLocation2);			
		
		Location removed1=testQueue.remove();
		assertEquals("Returned element should be testLocation1.", removed1,testLocation1);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		
		//when testLocation3 is added it should be at index 0
		testQueue.add(testLocation3);
		//when testLocation4 is added it should be in a bigger array
		testQueue.add(testLocation4);
		
		//There should be 3 elements in the queue and they should be in order
		Location removed2=testQueue.remove();
		assertEquals("Returned element should be testLocation2.", removed2,testLocation2);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed3=testQueue.remove();
		assertEquals("Returned element should be testLocation3.", removed3,testLocation3);
		assertFalse("Queue should not be empty", testQueue.isEmpty());
		Location removed4=testQueue.remove();
		assertEquals("Returned element should be testLocation4.", removed4,testLocation4);
		assertTrue("Queue should be empty", testQueue.isEmpty());
	}
}

