package project3;

import static org.junit.Assert.*;


import org.junit.Test;

/**
 * Tests for stack implementation of PossibleLocations
 * @author Alice Han
 *
 */
public class PossibleLocationsStackTest {
	//test isEmpty on empty stack
	@Test
	public void testIsEmptyWhenEmpty() {
		//create empty stack
		PossibleLocationsStack testStack=new PossibleLocationsStack();
		//assertTrue to confirm stack is empty
		assertTrue("Stack should be empty", testStack.isEmpty());
	}

	//test isEmpty on not empty stack
	@Test
	public void testIsEmptyWhenNotEmpty() {
		//create empty stack
		PossibleLocationsStack testStack=new PossibleLocationsStack();
		Location testLocation1=new Location(1,2);
		//add element to stack
		testStack.add(testLocation1);
		//assertFalse to confirm stack is not empty
		assertFalse("Stack should not be empty", testStack.isEmpty());
	}

	//test add, remove, and then isEmpty
	@Test
	public void testAddRemove() {
		//create empty stack
		PossibleLocationsStack testStack=new PossibleLocationsStack();
		Location testLocation1=new Location(1,2);
		//add element to stack
		testStack.add(testLocation1);
		//assertFalse to confirm stack is not empty at this point
		assertFalse("Stack should not be empty", testStack.isEmpty());
		//remove latest addition to stack
		Location removed = testStack.remove();
		//check if the add and remove methods correctly dealt with the right element
		assertEquals("Element should be testLocation1.", removed,testLocation1);
		//assertTrue to confirm stack is empty
		assertTrue("Stack should be empty", testStack.isEmpty());
	}

	//test add multiple elements, remove all elements, and test isEmpty after each action
	@Test
	public void testAddRemoveMultiple() {
		//create empty stack
		PossibleLocationsStack testStack=new PossibleLocationsStack();
		Location testLocation1=new Location(1,2);
		Location testLocation2=new Location(3,4);
		Location testLocation3=new Location(5,6);
		//add multiple elements
		testStack.add(testLocation1);
		assertFalse("Stack should not be empty", testStack.isEmpty());
		testStack.add(testLocation2);
		assertFalse("Stack should not be empty", testStack.isEmpty());
		testStack.add(testLocation3);
		assertFalse("Stack should not be empty", testStack.isEmpty());
		//remove all elements and check if the add and remove methods correctly dealt with the right element
		Location removed1 = testStack.remove();
		assertEquals("Element should be testLocation1.", removed1,testLocation3);
		assertFalse("Stack should not be empty", testStack.isEmpty());
		Location removed2 = testStack.remove();
		assertEquals("Element should be testLocation2.", removed2,testLocation2);
		assertFalse("Stack should not be empty", testStack.isEmpty());
		Location removed3 = testStack.remove();
		assertEquals("Element should be testLocation3.", removed3,testLocation1);
		assertTrue("Stack should be empty", testStack.isEmpty());
		//remove once more to check if it correctly return null
		Location removed4 = testStack.remove();
		assertEquals("Returned element should be null.", removed4,null);
		//after adding and removing elements it should return empty
		assertTrue("Stack should be empty", testStack.isEmpty());
	}
	//test add method when adding null to stack
	@Test
	public void testAddNull() {
		//create empty stack
		PossibleLocationsStack testStack=new PossibleLocationsStack();
		//test adding with null
		try {
			testStack.add(null);
		}
		//if the null pointer is thrown then all is well
		catch (NullPointerException success) {
			return;
		}
		//if it reaches this line then exception handling failed
		fail("Didn't throw Null Pointer exception");
	}

}
