package project3;
/**
 * This is an implementation of the PossibleLocations interface used to make a queue
 * The goal is to store location spaces and search for a way out of a maze algorithm
 * This is a queue so it follows the First In First Out Rule
 * 
 * @author Alice Han
 *
 */
public class PossibleLocationsQueue implements PossibleLocations{
	//made default capacity 10
	private int capacity=10;
	private Location[] queueArray;
	private int size=0;
	//made variables to keep track of front and back of queue
	private int front=0;
	private int back=size-1;
	
	//No parameter constructor will make a queue of capacity 10
	PossibleLocationsQueue(){
		queueArray=new Location[capacity];
	}
	//One parameter constructor will take in a initial capacity and create a queue with that capacity
	PossibleLocationsQueue(int initialCapacity) throws IllegalArgumentException{
		//if the parameter is a negative number we will throw exception
		if(initialCapacity<0) {
			throw new IllegalArgumentException();
		}
		//if capacity is valid we will create a queue of that capacity
		capacity=initialCapacity;
		queueArray= new Location[initialCapacity];
	}
	
	/**
	 * Add a SquarePosition object to the set.
	 * @param s
	 *    object to be added
	*/
	@Override
	public void add(Location s) {
		//if s is null we throw a NullPointerException
		if (s==null) {
			throw new NullPointerException();
		}
		//if the queue is full then make and store all the elements in a larger array
		if (size==capacity) {
			queueArray=makeLarger();
		}
		//we want to add back to the next available index even if it is in the beginning so
		//that we are using the available space while maintaining the order
		//in which they are entered so we calculate using back and capacity
		back=(back+1)%capacity;
		queueArray[back]=s;
		size++;
	}

	/**
	 * Remove the next object from the set. The specific
	 * item returned is determined by the underlying structure
	 * of set representation.
	 * @return
	 *    the next object, or null if set is empty
	 */
	@Override
	public Location remove() {
		//if the queue is empty there is nothing to return so return null
		if(size==0)return null;
		//we return the first element we put into the queue which is indicated by front
		Location temp=queueArray[front];
		queueArray[front]=null;
		//after we store the front element we set front to the next oldest element
		front=(front+1)%capacity;
		size--;
		return temp;
	}

	/**
	 * Determines if set is empty or not.
	 * @return
	 *    true, if set is empty,
	 *    false, otherwise.
	 */
	@Override
	public boolean isEmpty() {
		//if there is no more elements in the list return true
		if(size==0)return true;
		return false;
	}
	/**
	 * This method makes a new array with a doubled capacity of the current array
	 * with all the elements of the current array in order of when they were added
	 * @return a larger, ordered version of the current queue
	 */
	private Location[] makeLarger() {
		capacity=capacity*2;
		Location[]newArray=new Location[capacity];
		//if front is less than back that means everything is in order and we copy directly
		if(front<back) {
			int counter=0;
			for (int i=front;i<queueArray.length; i++) {
				newArray[counter]=queueArray[i];
				counter++;
			}
		}
		//if front is greater than back then we make the new array while adding front to end of the array first
		//then from back to front
		else {
			int counter=0;
			for (int i=front;i<queueArray.length; i++) {
				newArray[counter]=queueArray[i];
				counter++;
			}
			for (int i=0;i<back+1; i++) {
				newArray[counter]=queueArray[i];
				counter++;
			}
			front=0;
			back=size-1;
		}
		//return larger array
		return newArray;
	}
	

}
